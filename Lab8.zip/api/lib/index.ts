import App from './app';
import IndexController from "./controllers/index.controllers";
import DataController from "./controllers/data.controllers";
import UserController from "./controllers/user.controllers";

const app: App = new App([
    new UserController(),
    new DataController(),
    new IndexController()
]);

app.listen();